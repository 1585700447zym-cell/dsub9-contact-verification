# 独立静态复现包
需要 Python、NumPy、MuJoCo。此包不包含引擎安装文件。参考结果使用 3.9.0；3.13.0 是单独可行性对照。
在 VS Code 打开解压文件夹，在终端运行：python reproduce.py --output result.json
可选静态窗口：python reproduce.py --view new_native
脚本自动恢复 keyframe 0，不执行动力学积分；窗口交互尚未经人工验收。相同 XML 在 3.9.0 返回的最大深度依次约为 223.602245、539.846678、3.570487 微米。
3.13.0 对应约为 0.000010158、0、3.570487 微米；无接触不自动代表正确。完整回归与停止验收仍待完成。
