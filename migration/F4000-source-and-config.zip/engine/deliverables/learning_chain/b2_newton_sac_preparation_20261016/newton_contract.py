"""Pure standard-library N2 preparation contract; grants no execution capability.

The caller supplies the selected traditional controller's ACTUAL receipt and
its file SHA256. This module freezes their values; it cannot authenticate the
file itself, qualify physics, import a numerical runtime, or admit training.
"""
from copy import deepcopy
import hashlib
import json
import math
import re


SEED = 2026092716
WIDTH = 137
_LAYOUT = (
    ('wrench_history_M',24), ('relative_position_m',3), ('relative_rotation_world_rad',3),
    ('velocity_world',6), ('maximum_advance_m',1), ('base_command',6),
    ('previous_limited_command',6), ('previous_residual',4), ('policy_phase',5),
    ('physical_phase',4), ('recovery_phase',4), ('decision',9), ('pending',1),
    ('action_active',1), ('simulation_valid',1), ('latched_guards',7),
    ('invalid_latched',1), ('total_budget_remaining_s',1), ('search_budget_remaining_s',1),
    ('search_budget_valid',1), ('searches_remaining',1), ('recoveries_remaining',1),
    ('admittance_velocity',4), ('admittance_offset',4), ('spiral_theta_rad',1),
    ('search_origin_m',3), ('search_origin_valid',1), ('stall_progress_m',1),
    ('stall_span_s',1), ('stall_valid',1), ('phase_elapsed_s',1), ('hold_elapsed_s',1),
    ('hold_valid',1), ('stop_elapsed_s',1), ('stop_valid',1), ('wait_elapsed_s',1),
    ('wait_valid',1), ('reference_position_error_m',3), ('reference_rotation_error_world_rad',3),
    ('relative_drive_reference_m',3), ('search_reference_xy_m',2), ('search_reference_valid',1),
    ('episode_peak_z_m',1), ('episode_peak_valid',1), ('net_search_remaining_m',1),
    ('net_search_valid',1), ('rotation_risk_elapsed_s',1), ('rotation_risk_valid',1),
    ('search_load_elapsed_s',1), ('search_load_valid',1), ('admittance_xy_rebase_count',1),
    ('reference_release_pending',1), ('previous_reference_filter_fraction',1),
)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def _pin(value):
    if not isinstance(value, str) or re.fullmatch('[0-9a-f]{64}', value) is None:
        raise ValueError('An explicit SHA256 pin is required')
    return value


def _positive(value):
    if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
        raise ValueError('Positive finite numeric parameter required')


def _point(name, x, y, roll, pitch):
    return dict(id=name, x_um=float(x), y_um=float(y), roll_deg=float(roll),
                pitch_deg=float(pitch), yaw_deg=0., start_origin_z_m=-.005,
                target_depth_m=.005)


def training_cases():
    """Four magnitude corners allocated to four XY quadrants, all development."""
    return [_point('N2_T1',150,150,.5,.5), _point('N2_T2',-150,150,-1,1),
            _point('N2_T3',-300,-300,-.5,-.5), _point('N2_T4',300,-300,1,-1)]


def evaluation_cases():
    """Each training pose plus its full-sign mirror; two poses per quadrant."""
    points = []
    for point in training_cases():
        points.append(point)
        points.append(_point(point['id']+'_MIRROR',
            *[-point[k] for k in ('x_um','y_um','roll_deg','pitch_deg')]))
    return points


def case_table():
    return dict(training=training_cases(), evaluation=evaluation_cases())


def _validate_table(table):
    if not isinstance(table, dict) or canonical(table) != canonical(case_table()):
        raise ValueError('Explicit four-quadrant training and mirror evaluation table required')


def case_kwargs(point):
    """Translate only one of the registered development poses, including Z."""
    if canonical(point) not in [canonical(p) for p in evaluation_cases()]:
        raise ValueError('Unregistered N2 pose, start or target travel')
    return dict(name=point['id'], x_offset_m=point['x_um']*1e-6,
                y_offset_m=point['y_um']*1e-6, roll_rad=math.radians(point['roll_deg']),
                pitch_rad=math.radians(point['pitch_deg']),
                start_origin_z_m=point['start_origin_z_m'], target_depth_m=point['target_depth_m'])


def preparation_plan():
    points = evaluation_cases()
    candidates = [points[0], points[5]]  # T1 and mirror(T3): positive XY and +RP.
    pending = [p for p in points if p not in candidates]
    return dict(base_learning_dynamic_episodes=17, training_episodes=8,
        final_development_evaluations=8, representative_restore_episodes=1,
        formal_updates=2000, common_baseline_reuse_candidates=candidates,
        common_baselines_pending=pending, additional_common_baselines_pending=True,
        nonzero_integration_preflight_pending=True, proposed_nonzero_preflight_episodes=1,
        proposed_new_dynamic_episodes=24, registered_total_dynamic_cap=None,
        complete_fair_matrix=False,
        registration_status='additional_B2_evidence_and_nonzero_gate_not_yet_bound')


def schedule(table):
    """Seventeen learning-related starts only; pending B2/gate are excluded."""
    _validate_table(table)
    rows = []
    for stage in ('warmup','online','final','restore'):
        points = table['training'] if stage in ('warmup','online') else table['evaluation']
        if stage == 'restore': points = points[:1]
        for i, point in enumerate(points):
            updates = 500 if stage == 'online' else 0
            before = (500*i if stage == 'online' else 0 if stage == 'warmup' else 2000)
            rows.append(dict(id=stage+'_F50_'+point['id'], stage=stage, mode='F50',
                case_index=i, case=deepcopy(point), optimizer_steps=before,
                updates_after_episode=updates, data_use='development_only',
                training_publication=stage in ('warmup','online')))
    return rows


def _validate_schema(schema, controller):
    if not isinstance(schema, list) or len(schema) != len(_LAYOUT):
        raise ValueError('Complete actual 137D schema is required')
    offset = 0
    fields = {}
    for field, (name, width) in zip(schema, _LAYOUT):
        if (not isinstance(field, dict) or field.get('name') != name or
            type(field.get('start')) is not int or field['start'] != offset or
            type(field.get('width')) is not int or field['width'] != width):
            raise ValueError('Schema names, widths or continuous offsets differ')
        scales = field.get('scale')
        if not isinstance(scales, list) or len(scales) != width:
            raise ValueError('Every schema component needs an explicit scale')
        for value in scales: _positive(value)
        if not isinstance(field.get('unit'), str) or not isinstance(field.get('source'), str):
            raise ValueError('Actual schema unit and source are required')
        fields[name] = field
        offset += width
    if offset != WIDTH: raise ValueError('137-dimensional layout required')
    if (fields['wrench_history_M']['scale'] != ([5.]*3+[.1]*3)*4 or
        fields['wrench_history_M']['unit'] != 'N,Nm'):
        raise ValueError('Wrench history must retain raw N/Nm and normalize by 5N/0.1Nm')
    radius, pitch = controller['spiral_radius_m'], controller['spiral_pitch_m']
    if fields['search_reference_xy_m']['scale'] != [radius, radius]:
        raise ValueError('Search-reference scale differs from selected controller radius')
    if not math.isclose(fields['spiral_theta_rad']['scale'][0], 2*math.pi*radius/pitch,
                        rel_tol=1e-12, abs_tol=1e-12):
        raise ValueError('Spiral angle scale differs from selected radius/pitch')


def _validate_common(common):
    try:
        canonical(common)
        p, d, c, a = [common[k] for k in ('profile','dynamic_config','controller_config','admittance_config')]
        if p['id'] != 'newton_force_N2_damped_v1':
            raise ValueError('This preparation requires the repaired N2 force domain')
        if any(p.get(k) is not False for k in ('hardware_qualified','training_admitted',
                                              'geometry_changed','mass_inertia_changed','friction_changed')):
            raise ValueError('No hardware/training qualification or geometry change may be inferred')
        if (p['force_guard_N'] != 5. or p['torque_guard_Nm'] != .1 or p['search_force_N'] != 2. or
            d['stop_force_N'] != 5. or d['stop_torque_Nm'] != .1 or
            c['force_guard_N'] != 5. or c['search_force_N'] != 2. or
            d['control_period'] != .002 or d['timestep'] != .0002 or p['timestep'] != .0002 or
            d['reference_lead_m'] != p['reference_lead_m'] or
            d['reference_lead_rad'] != p['reference_lead_rad']):
            raise ValueError('Profile, drive, controller, loads or control-time units disagree')
        if p['force_reference'] != 'M/world' or p['torque_guard_reference'] != 'G/world':
            raise ValueError('Force and torque reference points differ')
        for mapping in (d, c):
            for key, value in mapping.items():
                if type(value) in (int, float): _positive(value)
        if d['collision_backend'] != 'native': raise ValueError('Native contact domain required')
        kd = common['effective_kd']
        if not isinstance(kd, list) or len(kd) != 6: raise ValueError('Six actual damping values required')
        for value in kd: _positive(value)
        for key in ('virtual_mass','damping','velocity_limit','correction_budget'):
            if not isinstance(a[key], list) or len(a[key]) != 4: raise ValueError('Four admittance axes required')
            for value in a[key]: _positive(value)
        _positive(a['z_speed'])
        _pin(common['model_xml_sha256'])
        if not isinstance(common['actual_model'], dict) or not isinstance(common['runtime'], dict):
            raise ValueError('Actual model and runtime metadata must be frozen')
        candidates = dict(original=(.00012,.00004,.0001),
                          exit_50um=(.00012,.00004,.00005),
                          coverage_180um=(.00018,.00009,.0001))
        expected = candidates.get(common['variant'])
        if expected is None or tuple(c[k] for k in ('spiral_radius_m','spiral_pitch_m','search_exit_advance_m')) != expected:
            raise ValueError('Receipt variant and actual controller configuration disagree')
        _validate_schema(common['schema'], c)
    except (KeyError, TypeError, OverflowError) as exc:
        raise ValueError('Incomplete N2 common-domain receipt') from exc


def _freeze_domain(receipt):
    try:
        canonical(receipt)
        if (receipt.get('status') != 'finished' or
            any(receipt.get(k) is not True for k in ('healthy','valid','stopped','audit_passed','preflight_passed')) or
            type(receipt.get('policy_calls')) is not int or receipt['policy_calls'] != 0 or
            type(receipt.get('training_updates')) is not int or receipt['training_updates'] != 0 or
            receipt.get('outcome') not in ('FULL_SUCCESS','TASK_FAILURE')):
            raise ValueError('Completed healthy traditional-only receipt required')
        facts = receipt['guard_facts']
        if (facts.get('simulation_valid') is not True or
            any(facts.get(k) != [] for k in ('invalid_reasons','contact_reasons','motion_reasons'))):
            raise ValueError('Invalid/guarded receipt cannot define this initial training domain')
        common = {k: deepcopy(receipt[k]) for k in ('variant','profile','dynamic_config',
                  'effective_kd','controller_config','admittance_config','model_xml_sha256','actual_model','runtime')}
        common['schema'] = deepcopy(receipt['observation_schema'])
        _validate_common(common)
        return common
    except (KeyError, TypeError, OverflowError) as exc:
        raise ValueError('Incomplete selected traditional receipt') from exc


def _compose(common, source, table, plan):
    return dict(version='newton_N2_sac_preparation_v1', mode='F50',
        preparation_only=True, training_admitted=False, physical_admission='not_granted',
        data_use='development_only', independent_test_episodes=0,
        observation_version='newton_actual_receipt_schema_v1', width=WIDTH,
        schema=deepcopy(common['schema']), common=deepcopy(common), common_sha256=digest(common),
        source=deepcopy(source), case_table=deepcopy(table), plan=deepcopy(plan),
        action_scale=[.00005,.00005,.0005,.0005],
        reference_filter='residual_reference_continuation_v2',
        initialization=dict(weights='fresh_random_only',replay='empty_new_domain_only',old_F2000_reused=False),
        learning=dict(learning_rate=.0003,actor_learning_rate=.0003,batch_size=256,replay_capacity=116000,
            network=[256,256],seed=SEED,torch_threads=1,device='cpu',entropy_initial=.01,
            target_entropy=-4.,tau=.005,max_gradient_batches=2000,
            critic_boundary_rows=16,exact_terminal_tail=True),
        warmup=dict(episodes=4,hold_cycles=50,min_active_rows=256,min_active_cases=2),
        online=dict(episodes=4,batches_per_episode=500),discount_time_constant_s=10.,
        reward=dict(version='newton_N2_raw_load_reward_v1',target_travel_m=.005,
            progress_weight=5.,time_weight_per_s=.1,force_weight_per_s=.2,torque_weight_per_s=.2,
            force_scale_N=5.,torque_G_scale_Nm=.1,force_reference='M/world',torque_reference='G/world',
            raw_load_units='N,Nm',terminal=dict(FULL_SUCCESS=10.,TASK_FAILURE=-2.,
                CONTACT_GUARD=-10.,MOTION_VIOLATION=-10.,INVALID_SIMULATION=0.,
                STOP_NOT_QUALIFIED=0.,EXTERNAL_TRUNCATION=0.)),
        attempts=schedule(table))


def build_config(receipt, *, receipt_sha256, case_table, plan):
    """Freeze caller-supplied actual receipt; never treat this as admission."""
    _pin(receipt_sha256)
    _validate_table(case_table)
    if canonical(plan) != canonical(preparation_plan()):
        raise ValueError('Only the explicitly incomplete preparation plan is supported')
    common = _freeze_domain(receipt)
    source = dict(case_id=receipt['case_id'], receipt_sha256=receipt_sha256,
                  receipt_content_sha256=digest(receipt))
    return _compose(common, source, case_table, plan)


def validate_config(config, *, expected_digest):
    """Require an external config pin plus the fixed non-executing contract."""
    _pin(expected_digest)
    if digest(config) != expected_digest: raise ValueError('Configuration digest changed')
    try:
        common, source, table, plan = [config[k] for k in ('common','source','case_table','plan')]
        _validate_common(common)
        _validate_table(table)
        _pin(source['receipt_sha256'])
        _pin(source['receipt_content_sha256'])
        if set(source) != {'case_id','receipt_sha256','receipt_content_sha256'} or not isinstance(source['case_id'], str):
            raise ValueError('Actual receipt identity is incomplete')
        if canonical(plan) != canonical(preparation_plan()):
            raise ValueError('The additional common evidence is still pending')
        if canonical(config) != canonical(_compose(common,source,table,plan)):
            raise ValueError('Preparation scope, learning, reward or case schedule changed')
    except (KeyError, TypeError, OverflowError) as exc:
        raise ValueError('Incomplete N2 preparation configuration') from exc


def verify_same_domain(config, receipt):
    """Compare another healthy traditional receipt, ignoring its case/outcome."""
    validate_config(config, expected_digest=digest(config))
    if canonical(_freeze_domain(receipt)) != canonical(config['common']):
        raise ValueError('Receipt belongs to a different model/control/normalization domain')
